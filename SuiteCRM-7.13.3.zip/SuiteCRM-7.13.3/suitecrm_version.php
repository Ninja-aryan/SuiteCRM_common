<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.13.3';
$suitecrm_timestamp = '2023-04-24 12:00:00';
